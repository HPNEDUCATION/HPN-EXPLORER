import { ChatMessage } from "../types";

// The browser only talks to our own server (/api/chat). No secret key here.
export const getGeminiResponse = async (
  history: ChatMessage[],
  userMessage: string,
  currentDistrict?: string,
  lang: 'en' | 'pa' = 'en'
): Promise<string> => {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      history: history.filter(m => !m.isError).map(m => ({ role: m.role, text: m.text })),
      message: userMessage,
      district: currentDistrict,
      lang,
    }),
  });
  if (!res.ok) throw new Error('Failed to get response from the guide.');
  const data = await res.json();
  return data.text || "I'm sorry, I couldn't generate a response about Punjab right now.";
};
