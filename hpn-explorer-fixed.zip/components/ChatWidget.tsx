import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, Loader2 } from 'lucide-react';
import { ChatMessage } from '../types';
import { getGeminiResponse } from '../services/geminiService';
import { Lang, T } from '../i18n';

interface ChatWidgetProps {
  currentDistrict?: string;
  lang: Lang;
}

const ChatWidget: React.FC<ChatWidgetProps> = ({ currentDistrict, lang }) => {
  const t = T[lang];
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: T[lang].chatHello }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Reset chat slightly when district changes to acknowledge context switch
  useEffect(() => {
    if (currentDistrict) {
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: t.chatDistrict(currentDistrict) 
      }]);
    }
  }, [currentDistrict]);

  useEffect(() => {
    setMessages([{ role: 'model', text: T[lang].chatHello }]);
  }, [lang]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await getGeminiResponse(messages, userMsg.text, currentDistrict, lang);
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: t.chatError, isError: true }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-none">
      {isOpen && (
        <div className="pointer-events-auto bg-white rounded-2xl shadow-2xl w-[90vw] md:w-96 h-[500px] max-h-[80vh] flex flex-col mb-4 overflow-hidden border border-slate-200 animate-in slide-in-from-bottom-10 fade-in duration-300">
          <div className="bg-punjab-600 p-4 flex justify-between items-center text-white">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-white/20 rounded-full">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold">HPN Explorer</h3>
                <p className="text-xs text-punjab-100">{t.chatGuide(currentDistrict)}</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="p-1 hover:bg-white/20 rounded-full transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
            {messages.map((msg, index) => (
              <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl p-3 text-sm ${msg.role === 'user' ? 'bg-punjab-600 text-white rounded-br-none' : 'bg-white text-slate-700 shadow-sm border border-slate-100 rounded-bl-none'} ${msg.isError ? 'bg-red-50 text-red-600' : ''}`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white rounded-2xl rounded-bl-none p-3 shadow-sm border border-slate-100 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-punjab-500" />
                  <span className="text-xs text-slate-400">{t.chatThinking}</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-3 bg-white border-t border-slate-100">
            <p className="text-[11px] text-slate-400 text-center mb-2">{t.chatWarn}</p>
            <div className="relative flex items-center">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={t.chatPlaceholder}
                className="w-full bg-slate-100 text-slate-800 rounded-full pl-4 pr-12 py-3 focus:outline-none focus:ring-2 focus:ring-punjab-500/50 transition-all text-sm"
              />
              <button onClick={handleSend} disabled={!input.trim() || isLoading} className="absolute right-2 p-2 bg-punjab-600 text-white rounded-full hover:bg-punjab-700 disabled:opacity-50 disabled:hover:bg-punjab-600 transition-colors">
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`pointer-events-auto shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 flex items-center justify-center w-14 h-14 rounded-full ${isOpen ? 'bg-slate-700 rotate-90' : 'bg-punjab-600'} text-white`}
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-7 h-7" />}
      </button>
    </div>
  );
};

export default ChatWidget;
