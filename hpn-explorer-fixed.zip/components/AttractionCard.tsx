import React from 'react';
import { PlaceItem } from '../types';
import { MapPin } from 'lucide-react';

interface AttractionCardProps {
  item: PlaceItem;
}

const AttractionCard: React.FC<AttractionCardProps> = ({ item }) => {
  return (
    <div className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 border border-slate-100">
      <div className="relative h-64 overflow-hidden">
        <img 
          src={item.imageUrl} 
          alt={item.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
          <p className="text-white font-medium">Explore Details &rarr;</p>
        </div>
      </div>
      <div className="p-6">
        <div className="flex flex-wrap gap-2 mb-3">
          {item.tags?.map((tag, idx) => (
            <span key={idx} className="text-xs font-semibold px-2 py-1 bg-punjab-100 text-punjab-900 rounded-full">
              {tag}
            </span>
          ))}
        </div>
        <h3 className="text-xl font-bold text-slate-800 mb-2">{item.name}</h3>
        {item.location && (
          <div className="flex items-center text-slate-500 text-sm mb-3">
            <MapPin className="w-4 h-4 mr-1" />
            <span>{item.location}</span>
          </div>
        )}
        <p className="text-slate-600 line-clamp-3">{item.description}</p>
      </div>
    </div>
  );
};

export default AttractionCard;