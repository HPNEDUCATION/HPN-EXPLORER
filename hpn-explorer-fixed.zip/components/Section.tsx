import React from 'react';

interface SectionProps {
  id: string;
  title: string;
  subtitle?: string;
  bgColor?: 'white' | 'gray';
  children: React.ReactNode;
}

const Section: React.FC<SectionProps> = ({ id, title, subtitle, bgColor = 'white', children }) => {
  return (
    <section 
      id={id} 
      className={`py-16 px-4 md:px-8 lg:px-16 ${bgColor === 'gray' ? 'bg-slate-50' : 'bg-white'}`}
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4 font-serif relative inline-block">
            {title}
            <span className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-16 h-1 bg-punjab-500 rounded-full"></span>
          </h2>
          {subtitle && (
            <p className="text-lg text-slate-600 max-w-2xl mx-auto mt-4">
              {subtitle}
            </p>
          )}
        </div>
        {children}
      </div>
    </section>
  );
};

export default Section;