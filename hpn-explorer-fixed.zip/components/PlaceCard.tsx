import React from 'react';
import { PlaceItem } from '../types';
import { PLACE_PA } from '../pa-content';
import { T } from '../i18n';
import { placeImage, onImgError } from '../images';
import { 
  MapPin, Building2, School, Church, Utensils, BedDouble, 
  Factory, Trees, Landmark, Moon, Sun, Star, Coffee, Home,
  ShoppingBag, Mountain
} from 'lucide-react';

interface PlaceCardProps {
  item: PlaceItem;
  category: string;
  districtId?: string;
  lang?: 'en' | 'pa';
}

const getIcon = (category: string, type?: string) => {
  const lowerType = type?.toLowerCase() || '';

  // Specific Religious Icons
  if (category === 'religious') {
    if (lowerType.includes('mosque') || lowerType.includes('masjid')) return <Moon className="w-4 h-4" />;
    if (lowerType.includes('mandir') || lowerType.includes('temple')) return <Sun className="w-4 h-4" />;
    if (lowerType.includes('church')) return <Church className="w-4 h-4" />;
    if (lowerType.includes('gurudwara')) return <Star className="w-4 h-4" />; 
    return <Landmark className="w-4 h-4" />;
  }

  // Specific Accommodation Icons
  if (category === 'accommodation') {
    if (lowerType.includes('dharmshala') || lowerType.includes('sarai')) return <Home className="w-4 h-4" />;
    return <BedDouble className="w-4 h-4" />; // Hotels
  }

  // Specific Food Icons
  if (category === 'food') {
    if (lowerType.includes('court')) return <Coffee className="w-4 h-4" />;
    return <Utensils className="w-4 h-4" />;
  }

  // General Categories
  switch(category) {
    case 'education': return <School className="w-4 h-4" />;
    case 'industry': return <Factory className="w-4 h-4" />;
    case 'farm': return <Trees className="w-4 h-4" />;
    case 'nature': return <Mountain className="w-4 h-4" />;
    case 'shopping': return <ShoppingBag className="w-4 h-4" />;
    case 'heritage': 
    case 'history': return <Landmark className="w-4 h-4" />;
    default: return <Building2 className="w-4 h-4" />;
  }
};

const PlaceCard: React.FC<PlaceCardProps> = ({ item, category, districtId, lang }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-slate-100 flex flex-col h-full group">
      <div className="relative h-48 bg-slate-200 overflow-hidden">
        <img 
          src={districtId ? placeImage(districtId, item.id) : '/placeholder.svg'}
          onError={onImgError}
          loading="lazy"
          alt={item.name} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-2 right-2 bg-white/95 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-punjab-700 flex items-center gap-1.5 shadow-sm border border-punjab-100">
          {getIcon(category, item.type)}
          {item.type || (lang === 'pa' ? T.pa.cat[category] : T.en.cat[category]) || category}
        </div>
      </div>
      <div className="p-4 flex-1 flex flex-col">
        <h3 className="text-lg font-bold text-slate-800 mb-1">{item.name}</h3>
        {item.location && (
          <div className="flex items-center text-slate-500 text-xs mb-3">
            <MapPin className="w-3 h-3 mr-1 text-punjab-500" />
            <span>{item.location}</span>
          </div>
        )}
        <p className="text-slate-600 text-sm line-clamp-3 mb-4 flex-1">{(lang === 'pa' && districtId && PLACE_PA[`${districtId}:${item.id}`]) || item.description}</p>
        {item.contact && (
          <div className="pt-3 border-t border-slate-100 text-xs text-slate-500 font-medium">
            📞 {item.contact}
          </div>
        )}
      </div>
    </div>
  );
};

export default PlaceCard;
