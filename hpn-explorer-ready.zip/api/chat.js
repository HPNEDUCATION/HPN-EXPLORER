// Server-side chat endpoint (Vercel serverless function).
// The secret GEMINI_API_KEY is read here and never sent to the browser.
import { GoogleGenAI } from '@google/genai';

const SYSTEM = `
You are HPN Explorer AI, a travel and cultural guide for the districts of Punjab, India.
Your knowledge covers History, Education, Religion (Gurudwaras, Mandirs, Mosques, Churches), Heritage, Farm Houses, Food, Accommodation, and Industry.
Be helpful and factual. If you are not sure about a fact, say so instead of guessing.
Keep answers short. Answer only questions about Punjab, travel, history, culture, education and industry.
`;

const MAX_MESSAGE = 500;
const MAX_HISTORY = 12;

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    res.status(500).json({ error: 'Server is not configured' });
    return;
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const message = String(body.message || '').slice(0, MAX_MESSAGE).trim();
    const lang = body.lang === 'pa' ? 'pa' : 'en';
    const district = body.district ? String(body.district).slice(0, 60) : '';
    if (!message) {
      res.status(400).json({ error: 'Empty message' });
      return;
    }
    const history = (Array.isArray(body.history) ? body.history : [])
      .slice(-MAX_HISTORY)
      .filter((m) => m && (m.role === 'user' || m.role === 'model') && typeof m.text === 'string')
      .map((m) => ({ role: m.role, parts: [{ text: m.text.slice(0, MAX_MESSAGE * 2) }] }));

    const context = district
      ? `The user is exploring the ${district} district. Focus on ${district} unless asked otherwise.`
      : 'The user is on the state-wide overview page.';

    const langRule = lang === 'pa'
      ? 'Reply in Punjabi (Gurmukhi script) unless the user writes in another language.'
      : 'Reply in English unless the user writes in another language.';

    const ai = new GoogleGenAI({ apiKey: key });
    const chat = ai.chats.create({
      model: process.env.GEMINI_MODEL || 'gemini-3.5-flash',
      config: { systemInstruction: `${SYSTEM}\n${context}\n${langRule}` },
      history,
    });
    const result = await chat.sendMessage({ message });
    res.status(200).json({ text: result.text || 'Sorry, I could not answer that right now.' });
  } catch (e) {
    console.error('chat error', e);
    res.status(500).json({ error: 'Failed to get response' });
  }
}
